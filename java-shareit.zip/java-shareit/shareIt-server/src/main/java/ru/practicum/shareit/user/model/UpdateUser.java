package ru.practicum.shareit.user.model;

public interface UpdateUser {
}