# java-shareit
Template repository for Shareit project.
