package ru.practicum.gateway.user.dto;

public interface UpdateUser {
}
